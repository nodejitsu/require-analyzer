
var dep1 = require('example-dep1')
  , dep1 = require('example-dep2');
