
[ 'dep1',
  'dep2',
  'dep3'
].map(function (e){
  return require(e)
})
