
(function x(){ x() })()
