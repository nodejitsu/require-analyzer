var dep1 = require('dep2-with-conflict-on-dep1')
  ,  dep1 = require('dep1');
