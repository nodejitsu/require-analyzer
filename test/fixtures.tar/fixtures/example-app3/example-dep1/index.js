

module.exports = {
  who: 'example-dep1',
  random: Math.random() 
};